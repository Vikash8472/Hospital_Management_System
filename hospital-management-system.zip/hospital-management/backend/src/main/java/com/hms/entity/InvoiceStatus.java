package com.hms.entity;

public enum InvoiceStatus {
    UNPAID,
    PAID,
    CANCELLED
}
