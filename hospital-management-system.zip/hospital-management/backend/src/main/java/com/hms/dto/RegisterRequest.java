package com.hms.dto;

import com.hms.entity.Role;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class RegisterRequest {
    @NotBlank
    private String name;

    @NotBlank @Email
    private String email;

    @NotBlank
    private String password;

    @NotBlank
    private String phone;

    private Role role; // ADMIN / DOCTOR / PATIENT

    // Optional extra fields depending on role
    private String specialization;   // for DOCTOR
    private String department;       // for DOCTOR
    private String gender;           // for PATIENT
    private String address;          // for PATIENT
}
