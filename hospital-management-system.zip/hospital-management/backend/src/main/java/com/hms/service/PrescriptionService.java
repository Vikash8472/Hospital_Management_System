package com.hms.service;

import com.hms.dto.PrescriptionRequest;
import com.hms.entity.Appointment;
import com.hms.entity.Prescription;
import com.hms.exception.ResourceNotFoundException;
import com.hms.repository.AppointmentRepository;
import com.hms.repository.PrescriptionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PrescriptionService {

    private final PrescriptionRepository prescriptionRepository;
    private final AppointmentRepository appointmentRepository;

    public Prescription createPrescription(PrescriptionRequest request) {
        Appointment appointment = appointmentRepository.findById(request.getAppointmentId())
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with id: " + request.getAppointmentId()));

        Prescription prescription = Prescription.builder()
                .appointment(appointment)
                .medicines(request.getMedicines())
                .notes(request.getNotes())
                .build();

        return prescriptionRepository.save(prescription);
    }

    public Prescription getByAppointmentId(Long appointmentId) {
        return prescriptionRepository.findByAppointmentId(appointmentId)
                .orElseThrow(() -> new ResourceNotFoundException("No prescription found for appointment id: " + appointmentId));
    }
}
