package com.hms.service;

import com.hms.dto.DoctorScheduleRequest;
import com.hms.entity.Doctor;
import com.hms.entity.DoctorSchedule;
import com.hms.exception.ResourceNotFoundException;
import com.hms.repository.DoctorRepository;
import com.hms.repository.DoctorScheduleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class DoctorService {

    private final DoctorRepository doctorRepository;
    private final DoctorScheduleRepository scheduleRepository;

    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }

    public Doctor getDoctorById(Long id) {
        return doctorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id: " + id));
    }

    public Doctor getDoctorByEmail(String email) {
        return doctorRepository.findByUserEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found for email: " + email));
    }

    public DoctorSchedule addSchedule(Long doctorId, DoctorScheduleRequest request) {
        Doctor doctor = getDoctorById(doctorId);

        DoctorSchedule schedule = DoctorSchedule.builder()
                .doctor(doctor)
                .dayOfWeek(request.getDayOfWeek())
                .startTime(request.getStartTime())
                .endTime(request.getEndTime())
                .slotDurationMinutes(request.getSlotDurationMinutes() != null ? request.getSlotDurationMinutes() : 30)
                .build();

        return scheduleRepository.save(schedule);
    }

    public List<DoctorSchedule> getSchedule(Long doctorId) {
        return scheduleRepository.findByDoctorId(doctorId);
    }
}
