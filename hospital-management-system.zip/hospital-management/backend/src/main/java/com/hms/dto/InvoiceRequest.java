package com.hms.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class InvoiceRequest {
    @NotNull
    private Long patientId;

    private Long appointmentId;

    private Double consultationFee;
    private Double medicineCharges;
    private Double otherCharges;
}
