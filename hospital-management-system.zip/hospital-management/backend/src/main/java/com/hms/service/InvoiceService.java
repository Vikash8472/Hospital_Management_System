package com.hms.service;

import com.hms.dto.InvoiceRequest;
import com.hms.entity.Appointment;
import com.hms.entity.Invoice;
import com.hms.entity.Patient;
import com.hms.exception.ResourceNotFoundException;
import com.hms.repository.AppointmentRepository;
import com.hms.repository.InvoiceRepository;
import com.hms.repository.PatientRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class InvoiceService {

    private final InvoiceRepository invoiceRepository;
    private final PatientRepository patientRepository;
    private final AppointmentRepository appointmentRepository;

    public Invoice generateInvoice(InvoiceRequest request) {
        Patient patient = patientRepository.findById(request.getPatientId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + request.getPatientId()));

        Appointment appointment = null;
        if (request.getAppointmentId() != null) {
            appointment = appointmentRepository.findById(request.getAppointmentId())
                    .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with id: " + request.getAppointmentId()));
        }

        double consultationFee = request.getConsultationFee() != null ? request.getConsultationFee() : 0.0;
        double medicineCharges = request.getMedicineCharges() != null ? request.getMedicineCharges() : 0.0;
        double otherCharges = request.getOtherCharges() != null ? request.getOtherCharges() : 0.0;
        double total = consultationFee + medicineCharges + otherCharges;

        Invoice invoice = Invoice.builder()
                .patient(patient)
                .appointment(appointment)
                .consultationFee(consultationFee)
                .medicineCharges(medicineCharges)
                .otherCharges(otherCharges)
                .totalAmount(total)
                .build();

        return invoiceRepository.save(invoice);
    }

    public List<Invoice> getPatientInvoices(Long patientId) {
        return invoiceRepository.findByPatientId(patientId);
    }

    public List<Invoice> getAllInvoices() {
        return invoiceRepository.findAll();
    }
}
