package com.hms.service;

import com.hms.dto.MedicalRecordRequest;
import com.hms.entity.Doctor;
import com.hms.entity.MedicalRecord;
import com.hms.entity.Patient;
import com.hms.exception.ResourceNotFoundException;
import com.hms.repository.DoctorRepository;
import com.hms.repository.MedicalRecordRepository;
import com.hms.repository.PatientRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class MedicalRecordService {

    private final MedicalRecordRepository medicalRecordRepository;
    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;

    public MedicalRecord addRecord(MedicalRecordRequest request) {
        Patient patient = patientRepository.findById(request.getPatientId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + request.getPatientId()));
        Doctor doctor = doctorRepository.findById(request.getDoctorId())
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id: " + request.getDoctorId()));

        MedicalRecord record = MedicalRecord.builder()
                .patient(patient)
                .doctor(doctor)
                .recordDate(request.getRecordDate() != null ? request.getRecordDate() : LocalDate.now())
                .diagnosis(request.getDiagnosis())
                .treatment(request.getTreatment())
                .attachmentUrl(request.getAttachmentUrl())
                .build();

        return medicalRecordRepository.save(record);
    }

    public List<MedicalRecord> getPatientHistory(Long patientId) {
        return medicalRecordRepository.findByPatientId(patientId);
    }
}
