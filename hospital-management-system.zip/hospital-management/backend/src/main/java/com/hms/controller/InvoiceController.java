package com.hms.controller;

import com.hms.dto.InvoiceRequest;
import com.hms.entity.Invoice;
import com.hms.service.InvoiceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/invoices")
@RequiredArgsConstructor
public class InvoiceController {

    private final InvoiceService invoiceService;

    @PostMapping("/generate")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Invoice> generate(@Valid @RequestBody InvoiceRequest request) {
        return ResponseEntity.ok(invoiceService.generateInvoice(request));
    }

    @GetMapping("/patient/{patientId}")
    @PreAuthorize("hasAnyRole('ADMIN','PATIENT')")
    public ResponseEntity<List<Invoice>> patientInvoices(@PathVariable Long patientId) {
        return ResponseEntity.ok(invoiceService.getPatientInvoices(patientId));
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<Invoice>> allInvoices() {
        return ResponseEntity.ok(invoiceService.getAllInvoices());
    }
}
