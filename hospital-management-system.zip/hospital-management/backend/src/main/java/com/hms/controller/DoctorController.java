package com.hms.controller;

import com.hms.dto.DoctorScheduleRequest;
import com.hms.entity.Doctor;
import com.hms.entity.DoctorSchedule;
import com.hms.service.DoctorService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/doctors")
@RequiredArgsConstructor
public class DoctorController {

    private final DoctorService doctorService;

    // Public: any logged in user can view doctor list (for booking appointments)
    @GetMapping
    public ResponseEntity<List<Doctor>> getAllDoctors() {
        return ResponseEntity.ok(doctorService.getAllDoctors());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Doctor> getDoctorById(@PathVariable Long id) {
        return ResponseEntity.ok(doctorService.getDoctorById(id));
    }

    @GetMapping("/me")
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<Doctor> getMyProfile(Authentication authentication) {
        return ResponseEntity.ok(doctorService.getDoctorByEmail(authentication.getName()));
    }

    @PostMapping("/{id}/schedule")
    @PreAuthorize("hasAnyRole('DOCTOR','ADMIN')")
    public ResponseEntity<DoctorSchedule> addSchedule(@PathVariable Long id,
                                                       @Valid @RequestBody DoctorScheduleRequest request) {
        return ResponseEntity.ok(doctorService.addSchedule(id, request));
    }

    @GetMapping("/{id}/schedule")
    public ResponseEntity<List<DoctorSchedule>> getSchedule(@PathVariable Long id) {
        return ResponseEntity.ok(doctorService.getSchedule(id));
    }
}
