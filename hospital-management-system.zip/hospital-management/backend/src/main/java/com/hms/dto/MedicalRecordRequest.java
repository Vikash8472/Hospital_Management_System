package com.hms.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;

@Data
public class MedicalRecordRequest {
    @NotNull
    private Long patientId;

    @NotNull
    private Long doctorId;

    private LocalDate recordDate;

    private String diagnosis;

    private String treatment;

    private String attachmentUrl;
}
