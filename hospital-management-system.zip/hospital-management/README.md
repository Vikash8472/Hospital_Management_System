# Hospital Management System

Full-stack Hospital Management System with JWT-based authentication and
role-based authorization (Admin / Doctor / Patient).

**Stack:** Java 17, Spring Boot 3, Spring Security + JWT, MySQL, React.js, Maven

## Folder Structure

```
hospital-management/
├── backend/          Spring Boot REST API
├── frontend/         React SPA
└── database/         schema.sql (reference — auto-created by Hibernate too)
```

## 1. Database Setup

Install MySQL and make sure it's running. Hibernate will auto-create the
`hospital_db` database and all tables on first backend startup
(`ddl-auto: update` in `application.yml`), so manual schema creation is
optional. If you'd rather set it up manually, run `database/schema.sql`.

Update credentials in `backend/src/main/resources/application.yml` if your
MySQL username/password differ from the defaults (`root` / `root`).

## 2. Backend Setup

```bash
cd backend
mvn clean install
mvn spring-boot:run
```

Backend runs on **http://localhost:8080**.

### Key endpoints

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Register (role: ADMIN/DOCTOR/PATIENT) |
| POST | `/api/auth/login` | Public | Login → returns JWT |
| GET | `/api/doctors` | Authenticated | List doctors |
| POST | `/api/doctors/{id}/schedule` | Doctor/Admin | Add doctor schedule |
| POST | `/api/appointments` | Patient | Book appointment |
| GET | `/api/appointments/my` | Patient | My appointments |
| GET | `/api/appointments/doctor` | Doctor | My patients' appointments |
| PUT | `/api/appointments/{id}/status` | Doctor/Admin | Update status |
| POST | `/api/prescriptions` | Doctor | Add prescription |
| POST | `/api/medical-records` | Doctor | Add medical record |
| GET | `/api/medical-records/patient/{id}` | Doctor/Patient/Admin | Patient history |
| POST | `/api/invoices/generate` | Admin | Generate invoice |
| GET | `/api/invoices/patient/{id}` | Admin/Patient | View invoices |

All protected endpoints require the header:
```
Authorization: Bearer <jwt_token>
```

## 3. Frontend Setup

```bash
cd frontend
npm install
npm start
```

Frontend runs on **http://localhost:3000** and talks to the backend at
`http://localhost:8080/api` (configured in `src/api/axiosInstance.js`).

## 4. Trying it out

1. Register a Patient account, an Admin account, and a Doctor account
   (`/register` page — pick the role from the dropdown).
2. Log in as **Patient** → book an appointment with a doctor.
3. Log in as **Doctor** → confirm/complete the appointment, write a
   prescription.
4. Log in as **Admin** → view all appointments, generate an invoice for the
   patient.

## Notes / Next Steps

- Passwords are hashed with BCrypt; JWT secret and expiry are in
  `application.yml` — change the secret before any real deployment.
- `ddl-auto: update` is convenient for development; switch to a proper
  migration tool (Flyway/Liquibase) for production.
- Doctor availability vs. appointment slot conflicts aren't validated yet —
  a good next feature to add.
- File uploads for medical record attachments currently just store a URL
  string; wire up actual file storage (S3, local disk, etc.) if needed.
