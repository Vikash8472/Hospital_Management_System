import React, { useEffect, useState } from 'react';
import api from '../../api/axiosInstance';
import { useAuth } from '../../context/AuthContext';

const PatientDashboard = () => {
  const { user } = useAuth();
  const [doctors, setDoctors] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [form, setForm] = useState({ doctorId: '', appointmentDateTime: '', reason: '' });
  const [message, setMessage] = useState('');

  const loadData = async () => {
    const [docRes, apptRes] = await Promise.all([
      api.get('/doctors'),
      api.get('/appointments/my'),
    ]);
    setDoctors(docRes.data);
    setAppointments(apptRes.data);
  };

  useEffect(() => { loadData(); }, []);

  const handleBook = async (e) => {
    e.preventDefault();
    setMessage('');
    try {
      await api.post('/appointments', form);
      setMessage('Appointment booked successfully!');
      setForm({ doctorId: '', appointmentDateTime: '', reason: '' });
      loadData();
    } catch (err) {
      setMessage(err.response?.data?.message || 'Booking failed');
    }
  };

  return (
    <div className="container">
      <h2>Welcome, {user?.name}</h2>

      <div className="card">
        <h3>Book an Appointment</h3>
        {message && <p>{message}</p>}
        <form onSubmit={handleBook}>
          <label>Doctor</label>
          <select
            value={form.doctorId}
            onChange={(e) => setForm({ ...form, doctorId: e.target.value })}
            required
          >
            <option value="">Select a doctor</option>
            {doctors.map((d) => (
              <option key={d.id} value={d.id}>
                Dr. {d.user?.name} — {d.specialization}
              </option>
            ))}
          </select>

          <label>Date & Time</label>
          <input
            type="datetime-local"
            value={form.appointmentDateTime}
            onChange={(e) => setForm({ ...form, appointmentDateTime: e.target.value })}
            required
          />

          <label>Reason</label>
          <textarea
            rows="3"
            value={form.reason}
            onChange={(e) => setForm({ ...form, reason: e.target.value })}
          />

          <button type="submit">Book Appointment</button>
        </form>
      </div>

      <div className="card">
        <h3>My Appointments</h3>
        <table>
          <thead>
            <tr><th>Doctor</th><th>Date & Time</th><th>Reason</th><th>Status</th></tr>
          </thead>
          <tbody>
            {appointments.map((a) => (
              <tr key={a.id}>
                <td>Dr. {a.doctor?.user?.name}</td>
                <td>{new Date(a.appointmentDateTime).toLocaleString()}</td>
                <td>{a.reason}</td>
                <td><span className={`badge ${a.status}`}>{a.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default PatientDashboard;
