import React, { useEffect, useState } from 'react';
import api from '../../api/axiosInstance';

const AdminDashboard = () => {
  const [doctors, setDoctors] = useState([]);
  const [patients, setPatients] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [invoiceForm, setInvoiceForm] = useState({
    patientId: '', appointmentId: '', consultationFee: '', medicineCharges: '', otherCharges: '',
  });
  const [message, setMessage] = useState('');

  const loadData = async () => {
    const [docRes, patRes, apptRes] = await Promise.all([
      api.get('/doctors'),
      api.get('/patients'),
      api.get('/appointments'),
    ]);
    setDoctors(docRes.data);
    setPatients(patRes.data);
    setAppointments(apptRes.data);
  };

  useEffect(() => { loadData(); }, []);

  const handleGenerateInvoice = async (e) => {
    e.preventDefault();
    setMessage('');
    try {
      const res = await api.post('/invoices/generate', invoiceForm);
      setMessage(`Invoice #${res.data.id} generated — Total ₹${res.data.totalAmount}`);
    } catch (err) {
      setMessage(err.response?.data?.message || 'Failed to generate invoice');
    }
  };

  return (
    <div className="container">
      <h2>Admin Dashboard</h2>

      <div className="card">
        <h3>Overview</h3>
        <p>Doctors: {doctors.length} | Patients: {patients.length} | Appointments: {appointments.length}</p>
      </div>

      <div className="card">
        <h3>All Appointments</h3>
        <table>
          <thead>
            <tr><th>Patient</th><th>Doctor</th><th>Date & Time</th><th>Status</th></tr>
          </thead>
          <tbody>
            {appointments.map((a) => (
              <tr key={a.id}>
                <td>{a.patient?.user?.name}</td>
                <td>Dr. {a.doctor?.user?.name}</td>
                <td>{new Date(a.appointmentDateTime).toLocaleString()}</td>
                <td><span className={`badge ${a.status}`}>{a.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h3>Generate Invoice</h3>
        {message && <p>{message}</p>}
        <form onSubmit={handleGenerateInvoice}>
          <label>Patient</label>
          <select
            value={invoiceForm.patientId}
            onChange={(e) => setInvoiceForm({ ...invoiceForm, patientId: e.target.value })}
            required
          >
            <option value="">Select patient</option>
            {patients.map((p) => (
              <option key={p.id} value={p.id}>{p.user?.name}</option>
            ))}
          </select>

          <label>Appointment ID (optional)</label>
          <input
            value={invoiceForm.appointmentId}
            onChange={(e) => setInvoiceForm({ ...invoiceForm, appointmentId: e.target.value })}
          />

          <label>Consultation Fee</label>
          <input
            type="number"
            value={invoiceForm.consultationFee}
            onChange={(e) => setInvoiceForm({ ...invoiceForm, consultationFee: e.target.value })}
          />

          <label>Medicine Charges</label>
          <input
            type="number"
            value={invoiceForm.medicineCharges}
            onChange={(e) => setInvoiceForm({ ...invoiceForm, medicineCharges: e.target.value })}
          />

          <label>Other Charges</label>
          <input
            type="number"
            value={invoiceForm.otherCharges}
            onChange={(e) => setInvoiceForm({ ...invoiceForm, otherCharges: e.target.value })}
          />

          <button type="submit">Generate Invoice</button>
        </form>
      </div>
    </div>
  );
};

export default AdminDashboard;
