import React, { useEffect, useState } from 'react';
import api from '../../api/axiosInstance';
import { useAuth } from '../../context/AuthContext';

const DoctorDashboard = () => {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState([]);
  const [rxForm, setRxForm] = useState({ appointmentId: '', medicines: '', notes: '' });
  const [message, setMessage] = useState('');

  const loadAppointments = async () => {
    const res = await api.get('/appointments/doctor');
    setAppointments(res.data);
  };

  useEffect(() => { loadAppointments(); }, []);

  const updateStatus = async (id, status) => {
    await api.put(`/appointments/${id}/status`, { status });
    loadAppointments();
  };

  const handlePrescribe = async (e) => {
    e.preventDefault();
    setMessage('');
    try {
      await api.post('/prescriptions', rxForm);
      setMessage('Prescription added successfully!');
      setRxForm({ appointmentId: '', medicines: '', notes: '' });
    } catch (err) {
      setMessage(err.response?.data?.message || 'Failed to add prescription');
    }
  };

  return (
    <div className="container">
      <h2>Welcome, Dr. {user?.name}</h2>

      <div className="card">
        <h3>My Appointments</h3>
        <table>
          <thead>
            <tr><th>Patient</th><th>Date & Time</th><th>Reason</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody>
            {appointments.map((a) => (
              <tr key={a.id}>
                <td>{a.patient?.user?.name}</td>
                <td>{new Date(a.appointmentDateTime).toLocaleString()}</td>
                <td>{a.reason}</td>
                <td><span className={`badge ${a.status}`}>{a.status}</span></td>
                <td>
                  <button onClick={() => updateStatus(a.id, 'CONFIRMED')}>Confirm</button>{' '}
                  <button onClick={() => updateStatus(a.id, 'COMPLETED')}>Complete</button>{' '}
                  <button onClick={() => updateStatus(a.id, 'CANCELLED')}>Cancel</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h3>Write Prescription</h3>
        {message && <p>{message}</p>}
        <form onSubmit={handlePrescribe}>
          <label>Appointment ID</label>
          <input
            value={rxForm.appointmentId}
            onChange={(e) => setRxForm({ ...rxForm, appointmentId: e.target.value })}
            required
          />
          <label>Medicines</label>
          <textarea
            rows="3"
            placeholder="e.g. Paracetamol 500mg - 1-0-1 x 5 days"
            value={rxForm.medicines}
            onChange={(e) => setRxForm({ ...rxForm, medicines: e.target.value })}
            required
          />
          <label>Notes</label>
          <textarea
            rows="2"
            value={rxForm.notes}
            onChange={(e) => setRxForm({ ...rxForm, notes: e.target.value })}
          />
          <button type="submit">Save Prescription</button>
        </form>
      </div>
    </div>
  );
};

export default DoctorDashboard;
