import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const roleHome = { ADMIN: '/admin', DOCTOR: '/doctor', PATIENT: '/patient' };

const Register = () => {
  const [form, setForm] = useState({
    name: '', email: '', password: '', phone: '', role: 'PATIENT',
    specialization: '', department: '', gender: '', address: '',
  });
  const [error, setError] = useState('');
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const user = await register(form);
      navigate(roleHome[user.role] || '/');
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed');
    }
  };

  return (
    <div className="container" style={{ maxWidth: 480 }}>
      <div className="card">
        <h2>Create Account</h2>
        {error && <p className="error">{error}</p>}
        <form onSubmit={handleSubmit}>
          <label>Full Name</label>
          <input name="name" value={form.name} onChange={handleChange} required />

          <label>Email</label>
          <input type="email" name="email" value={form.email} onChange={handleChange} required />

          <label>Password</label>
          <input type="password" name="password" value={form.password} onChange={handleChange} required />

          <label>Phone</label>
          <input name="phone" value={form.phone} onChange={handleChange} required />

          <label>Register as</label>
          <select name="role" value={form.role} onChange={handleChange}>
            <option value="PATIENT">Patient</option>
            <option value="DOCTOR">Doctor</option>
            <option value="ADMIN">Admin</option>
          </select>

          {form.role === 'DOCTOR' && (
            <>
              <label>Specialization</label>
              <input name="specialization" value={form.specialization} onChange={handleChange} />
              <label>Department</label>
              <input name="department" value={form.department} onChange={handleChange} />
            </>
          )}

          {form.role === 'PATIENT' && (
            <>
              <label>Gender</label>
              <input name="gender" value={form.gender} onChange={handleChange} />
              <label>Address</label>
              <input name="address" value={form.address} onChange={handleChange} />
            </>
          )}

          <button type="submit" style={{ width: '100%' }}>Register</button>
        </form>
        <p style={{ marginTop: 14 }}>
          Already have an account? <Link to="/login">Login</Link>
        </p>
      </div>
    </div>
  );
};

export default Register;
